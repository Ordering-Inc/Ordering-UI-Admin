import styled from 'styled-components'

export const WrapperOrderlist = styled.div``
