import styled from 'styled-components'

export const OrdersManageContainer = styled.div`
`
