import { createContext } from 'react'
export const ConfigFileContext = createContext()
