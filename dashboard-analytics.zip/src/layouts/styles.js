import styled from 'styled-components'

export const AdminMainContainer = styled.div`
  display: flex;
  margin-top: 65px;
`
