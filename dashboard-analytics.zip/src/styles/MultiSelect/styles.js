import styled from 'styled-components'

export const CheckBox = styled.div`
  color: #182964;
  svg {
    width: 25px;
    height: 25px;
  }
`
