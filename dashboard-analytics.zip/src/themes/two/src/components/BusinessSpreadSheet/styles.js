import styled from 'styled-components'

export const BusinessSpreadSheetContainer = styled.div``
