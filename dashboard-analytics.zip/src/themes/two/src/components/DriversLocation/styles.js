import styled from 'styled-components'
import React from 'react'

export const WrapperMap = styled.div`
  width: 100%;
  height: 100%;
  background-color: #EEE;
  position: relative;
`
