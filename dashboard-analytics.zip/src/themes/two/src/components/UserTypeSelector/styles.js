import styled from 'styled-components'

export const Option = styled.div`
  font-size: 14px;
  font-weight: 600;
  padding: 5px 0;
`
